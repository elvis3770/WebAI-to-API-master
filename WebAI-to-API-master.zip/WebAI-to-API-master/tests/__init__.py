# tests/__init__.py
"""
Test suite for WebAI-to-API.
"""
