# tests/test_endpoints/__init__.py
"""
Endpoint tests for WebAI-to-API.
"""
